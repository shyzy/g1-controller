# 在统信 UOS 上编译 G1 Controller APK

全程图形化操作 + 复制粘贴命令，不需要懂命令行。

---

## 准备工作：把文件传到 UOS 电脑上

**方法一：U盘**
把整个 `g1-webapp` 文件夹拷贝到 U 盘，插到 UOS 电脑上，复制到桌面。

**方法二：微信/钉钉文件传输**
把 `g1-webapp` 整个文件夹压缩成 zip，通过微信文件助手 / 钉钉发给自己的 UOS 版微信，下载到桌面解压。

---

## 第一步：安装 Docker（图形化）

> 如果已经装了 Docker 可以跳过这步

1. 打开 **应用商店**（UOS 左下角启动器 → 应用商店）
2. 搜索 **Docker** → 点击安装
3. 安装完成后，在启动器里找到 **Docker 桌面版** 打开

---

## 第二步：打开终端

1. 桌面空白处 **右键** → **在终端中打开**
2. 会弹出一个黑色窗口，这就是终端

---

## 第三步：运行以下命令（复制粘贴，按回车）

打开终端后，**分别复制粘贴下面的每一条命令，每次粘贴完按回车，等它跑完再粘下一条**。

### 1. 进入项目文件夹

```bash
cd ~/桌面/g1-webapp
```

> 如果你的文件夹不在桌面，把路径改成实际位置

### 2. 编译 APK

```bash
docker run --rm -v "$(pwd):/app" kivy/buildozer -v android debug
```

这条命令会自动下载编译环境，**第一次运行需要 20-30 分钟**（下载 SDK、NDK 等），后续只需要 2-3 分钟。

### 3. 编译完成后

APK 文件会出现在 `g1-webapp/bin/` 目录下，文件名类似：

```
g1controller-1.0.0-arm64-v8a-debug.apk
```

---

## 第四步：安装到 Retroid

**方法一：U盘**
把 APK 文件拷贝到 U 盘 → 插到 Retroid → 用文件管理器打开安装

**方法二：微信/钉钉**
把 APK 发给自己的微信 → Retroid 上登录微信 → 下载 → 安装

---

## 如果 Docker 装不上（备用方案）

如果应用商店没有 Docker，可以用终端直接安装 buildozer：

### 1. 打开终端，逐条运行：

```bash
cd ~/桌面/g1-webapp

# 安装编译工具
sudo apt update
sudo apt install -y git zip unzip python3-pip python3-venv openjdk-17-jdk

# 安装 buildozer
pip3 install --user buildozer

# 运行编译
python3 -m buildozer android debug
```

### 2. 等待编译完成（首次约 20-30 分钟）

### 3. APK 文件位置：`g1-webapp/bin/` 目录

---

## 完整文件清单

`g1-webapp/` 目录里这些文件都要有：

```
g1-webapp/
├── server.py          # G1 连接 + Web 服务器（内含 AES 密钥）
├── index.html         # 控制界面（按钮编辑页面）
├── setup.sh           # Termux 安装脚本（用不到）
├── shortcuts.json     # 快捷按钮配置（运行时自动生成）
├── buildozer.spec     # APK 编译配置
└── requirements.txt   # Python 依赖清单
```

如果缺少 `buildozer.spec` 或 `requirements.txt`，说一声我重新给你。
