#!/data/data/com.termux/files/usr/bin/bash
"""
G1 Web 控制器 Termux 一键安装脚本
在 Termux 里粘贴运行这一整段即可
"""

echo ""
echo "╔══════════════════════════════════╗"
echo "║  G1 Web 控制器 一键安装          ║"
echo "╚══════════════════════════════════╝"
echo ""

# 1. 更新 Termux 并安装 Python
echo "[1/4] 更新软件包..."
pkg update -y && pkg upgrade -y
pkg install python -y
pkg install python-pip -y

# 2. 创建项目目录
echo "[2/4] 创建项目文件..."
mkdir -p ~/g1-webapp
cd ~/g1-webapp

# 3. 安装 Python 依赖
echo "[3/4] 安装 Python 依赖..."
pip install unitree_webrtc_connect evdev

# 4. 创建服务器脚本
cat > ~/g1-webapp/server.py << 'SERVEREOF'
#!/data/data/com.termux/files/usr/bin/python3
import asyncio, json, os, sys, time, threading, queue, http.server, socketserver, urllib.parse

AES_KEY = "c48cc7b7edc6191f2b393f6990848cbc"
HTTP_PORT = 8888

DEFAULT_SHORTCUTS = [
    {"id": "sc1", "name": "跳舞", "icon": "\U0001f483", "color": "#e53e3e", "action": "SwitchMoveSkill", "param": "Dance"},
    {"id": "sc2", "name": "握手", "icon": "\U0001f91d", "color": "#805ad5", "action": "SwitchMoveSkill", "param": "HandShake"},
    {"id": "sc3", "name": "挥手", "icon": "\U0001f44b", "color": "#3182ce", "action": "SwitchMoveSkill", "param": "Wave"},
    {"id": "sc4", "name": "行走", "icon": "\U0001f6b6", "color": "#38a169", "action": "ToggleWalkStand", "param": ""},
    {"id": "sc5", "name": "急停", "icon": "\u26d4", "color": "#e53e3e", "action": "Damping", "param": ""},
    {"id": "sc6", "name": "行礼", "icon": "\U0001f3a9", "color": "#d69e2e", "action": "SwitchMoveSkill", "param": "Bow"},
]

CONFIG_FILE = os.path.expanduser("~/g1-webapp/shortcuts.json")
shortcuts = []
clients = set()

def load_shortcuts():
    global shortcuts
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE) as f: shortcuts = json.load(f); return
        except: pass
    shortcuts = DEFAULT_SHORTCUTS.copy(); save_shortcuts()

def save_shortcuts():
    with open(CONFIG_FILE, "w") as f: json.dump(shortcuts, f, ensure_ascii=False, indent=2)

class G1Control:
    def __init__(self):
        self.conn = None; self.state = "disconnected"; self.walk = False
    
    async def connect(self):
        from unitree_webrtc_connect import UnitreeWebRTCConnection, WebRTCConnectionMethod
        self.state = "connecting"; broadcast("正在连接...", "yellow")
        self.conn = UnitreeWebRTCConnection(WebRTCConnectionMethod.LocalAP, aes_128_key=AES_KEY)
        await self.conn.connect(); self.state = "connected"
        broadcast("G1 已连接", "green")
    
    async def send(self, cmd, param=""):
        if not self.conn: return
        try:
            if cmd == "ToggleWalkStand":
                await self.conn.sport_mode.StandUp()
                self.walk = not self.walk
            elif cmd == "SwitchMoveSkill" and param:
                await self.conn.sport_mode.SwitchMoveSkill(param)
            else:
                m = getattr(self.conn.sport_mode, cmd, None)
                if m: await m()
            broadcast(f"OK: {cmd}", "green")
        except Exception as e:
            broadcast(f"Error: {str(e)[:20]}", "red")
    
    async def move(self, f=0.0, l=0.0, r=0.0):
        if self.conn and self.state == "connected":
            try: await self.conn.sport_mode.Move(f, l, r)
            except: pass

g1 = G1Control()

def broadcast(t, d="green"):
    m = json.dumps({"type":"status","text":t,"dot":d})
    for q in list(clients):
        try: q.put_nowait(m)
        except: clients.discard(q)

def broadcast_shortcuts():
    m = json.dumps({"type":"shortcuts","list":shortcuts})
    for q in list(clients):
        try: q.put_nowait(m)
        except: clients.discard(q)

HTML = \"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>G1</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#1a1a2e;color:#fff;font-family:system-ui,sans-serif;min-height:100vh;display:flex;flex-direction:column}
.hdr{background:#16213e;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;font-size:13px}
.hdr .s{display:flex;align-items:center;gap:6px}
.dot{width:8px;height:8px;border-radius:50%;display:inline-block}
.green{background:#34a853}.red{background:#ea4335}.yellow{background:#fbbc04}
.jp{background:#16213e;margin:6px;border-radius:10px;padding:10px;display:flex;gap:12px;font-size:11px}
.jp div{flex:1;text-align:center;color:#9aa0a6}
.jp span{display:block;color:#fff;font-size:14px;margin-top:3px}
.gt{padding:8px 10px 2px;font-size:13px;color:#fbbc04;font-weight:600}
.gr{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;padding:6px 10px}
.sb{background:#0f3460;border:none;border-radius:10px;padding:14px 6px;color:#fff;text-align:center;cursor:pointer;transition:.1s;-webkit-tap-highlight-color:transparent}
.sb:active{transform:scale(.92)}
.sb .ic{font-size:26px;display:block;margin-bottom:2px}
.sb .nm{font-size:12px;font-weight:500}
.ft{padding:10px;text-align:center;font-size:10px;color:#5f6368;margin-top:auto}
</style>
</head>
<body>
<div class="hdr"><div class="s"><span class="dot green" id="d"></span><span id="st">连接中...</span></div></div>
<div class="jp"><div>左摇杆<br><span id="lx">0.00</span><br><span id="ly">0.00</span></div><div>右摇杆<br><span id="rx">0.00</span></div></div>
<div class="gt">快捷按钮</div>
<div class="gr" id="grid"></div>
<div class="ft">左摇杆移动 / 右摇杆旋转 / 屏幕按钮执行快捷指令</div>
<script>
var es=new EventSource("/events");
es.onmessage=function(e){
  try{var d=JSON.parse(e.data);
    if(d.type==="status"){document.getElementById("st").textContent=d.text;document.getElementById("d").className="dot "+d.dot}
    else if(d.type==="shortcuts"){render(d.list)}
    else if(d.type==="joy"){document.getElementById("lx").textContent=d.lx||"0";document.getElementById("ly").textContent=d.ly||"0";document.getElementById("rx").textContent=d.rx||"0"}
  }catch(e){}
};
function render(list){
  var g=document.getElementById("grid");g.innerHTML="";
  list.forEach(function(s){
    var b=document.createElement("div");b.className="sb";b.style.background=s.color||"#0f3460";
    b.innerHTML='<span class="ic">'+(s.icon||"\U0001f518")+'</span><span class="nm">'+(s.name||"")+'</span>';
    b.onclick=function(){fetch("/trigger",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:s.id})})};
    g.appendChild(b)
  })
}
</script>
</body>
</html>
\"""

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/events":
            self.send_response(200)
            self.send_header("Content-Type","text/event-stream")
            self.send_header("Cache-Control","no-cache")
            self.send_header("Access-Control-Allow-Origin","*")
            self.end_headers()
            q = queue.Queue(); clients.add(q)
            self.wfile.write(f"data: {json.dumps({'type':'shortcuts','list':shortcuts})}\n\n".encode())
            self.wfile.flush()
            try:
                while True:
                    try: m = q.get(timeout=20); self.wfile.write(f"data: {m}\n\n".encode()); self.wfile.flush()
                    except: self.wfile.write(":k\n\n".encode()); self.wfile.flush()
            except: pass
            finally: clients.discard(q)
            return
        self.send_response(200); self.send_header("Content-Type","text/html;charset=utf-8"); self.end_headers()
        self.wfile.write(HTML.encode("utf-8"))
    def do_POST(self):
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length",0))))
            sid = body.get("id","")
            s = next((s for s in shortcuts if s["id"]==sid), None)
            if s: threading.Thread(target=lambda: asyncio.run(g1.send(s["action"],s.get("param",""))), daemon=True).start()
        except: pass
        self.send_response(200); self.send_header("Content-Type","application/json"); self.end_headers()
        self.wfile.write(b'{"ok":true}')
    def log_message(self,*a): pass

def run_http():
    socketserver.TCPServer(("0.0.0.0",HTTP_PORT),Handler).serve_forever()

async def main():
    load_shortcuts()
    print("  G1 Web 控制器启动中...")
    try:
        await g1.connect()
    except Exception as e:
        broadcast(f"G1连接失败: {str(e)[:20]}","red")
    threading.Thread(target=run_http,daemon=True).start()
    try:
        import evdev
        devs = [evdev.InputDevice(p) for p in evdev.list_devices()]
        gp = None
        for d in devs:
            if any(k in d.name.lower() for k in ["joystick","gamepad","controller","retroid"]):
                gp = d; break
        if not gp:
            for d in devs:
                if evdev.ecodes.EV_ABS in d.capabilities():
                    gp = d; break
        if gp:
            print(f"  Handheld: {gp.name}")
            async for ev in gp.async_read_loop():
                if ev.type == evdev.ecodes.EV_ABS:
                    code = evdev.ecodes.ABS[ev.code]
                    v = ev.value/32767.0
                    if code in ("ABS_Y","ABS_RY"): v = -v
                    if abs(v) < 0.08: v = 0
                    if code == "ABS_Y": await g1.move(f=v*0.6)
                    elif code == "ABS_X": await g1.move(l=v*0.4)
                    elif code == "ABS_RX": await g1.move(r=v*0.5)
    except: pass
    while True: await asyncio.sleep(1)

asyncio.run(main())
SERVEREOF

chmod +x ~/g1-webapp/server.py

# 5. 启动
echo "[4/4] 启动 G1 Web 控制器..."
echo ""
echo "=========================================="
echo "  ✅ 安装完成！"
echo "  请在 Retroid 浏览器打开:"
echo ""
echo "  http://localhost:8888"
echo ""
echo "  如果不行，试试:"
echo "  http://127.0.0.1:8888"
echo "=========================================="
echo ""

# 获取 Retroid 的 IP
IP=$(ip addr show wlan0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
if [ -n "$IP" ]; then
  echo "  局域网其他设备访问:"
  echo "  http://$IP:8888"
  echo ""
fi

# 尝试自动打开浏览器
am start -a android.intent.action.VIEW -d "http://localhost:8888" 2>/dev/null || true

cd ~/g1-webapp
python server.py
